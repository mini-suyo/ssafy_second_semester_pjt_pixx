-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: filmmoa-db.cl6a2iw6q0pq.ap-northeast-2.rds.amazonaws.com    Database: filmmoa
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `hash_feed`
--

DROP TABLE IF EXISTS `hash_feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hash_feed` (
  `hash_feed_id` int NOT NULL AUTO_INCREMENT,
  `feed_id` int NOT NULL,
  `hashtag_id` int NOT NULL,
  PRIMARY KEY (`hash_feed_id`),
  KEY `FK2euclhhxf7v0c9grppm6xno64` (`feed_id`),
  KEY `FKhbb0s4wq07sq2kgiauddm651w` (`hashtag_id`),
  CONSTRAINT `FK2euclhhxf7v0c9grppm6xno64` FOREIGN KEY (`feed_id`) REFERENCES `feed` (`feed_id`),
  CONSTRAINT `FKhbb0s4wq07sq2kgiauddm651w` FOREIGN KEY (`hashtag_id`) REFERENCES `hashtag` (`hashtag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hash_feed`
--

LOCK TABLES `hash_feed` WRITE;
/*!40000 ALTER TABLE `hash_feed` DISABLE KEYS */;
INSERT INTO `hash_feed` VALUES (7,35,7),(9,46,9),(11,130,11),(12,130,12),(13,130,13),(14,167,14),(47,357,38),(48,356,23),(49,356,39),(50,356,22),(51,356,40),(52,358,20),(53,358,21),(54,358,18),(55,359,29),(56,359,41),(57,360,35),(58,360,33),(59,360,34),(60,360,36),(61,360,37),(63,431,38),(64,432,35),(65,432,36),(66,432,37),(67,432,33),(68,432,34),(69,433,23),(70,433,25),(71,433,22),(72,433,24),(73,434,20),(74,434,21),(75,434,19),(76,434,18),(77,435,43),(78,435,44);
/*!40000 ALTER TABLE `hash_feed` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-21 17:15:38
