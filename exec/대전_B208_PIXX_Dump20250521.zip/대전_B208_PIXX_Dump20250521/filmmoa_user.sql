-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: filmmoa-db.cl6a2iw6q0pq.ap-northeast-2.rds.amazonaws.com    Database: filmmoa
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `kakao_id` bigint NOT NULL,
  `nickname` varchar(45) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_token` int NOT NULL DEFAULT '3',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'2025-05-13 08:37:44',1,'ssafy','ssafy@gmail.com',1),(2,'2025-05-13 17:38:30',4236653683,'김세림','serim0504@naver.com',0),(5,'2025-05-09 04:12:56',5,'테스트2','test2@example.com',3),(6,'2025-05-14 09:25:00',4238217476,'김버니','boney.ssafy@gmail.com',0),(7,'2025-05-14 09:47:14',4257523000,'현희','jhc03032@naver.com',0),(8,'2025-05-14 10:20:30',4259991943,'임가현','nubddagi@naver.com',0),(9,'2025-05-14 10:23:22',4252679272,'민승용','alstmddyd147@naver.com',0),(10,'2025-05-14 10:35:23',4260012887,'연주','kong9434@daum.net',0),(11,'2025-05-14 10:53:21',4260038560,'testboney','wvwvwwwvvvwwvw@gmail.com',0),(13,'2025-05-14 11:00:32',4260049392,'전제후','jjh0211sg@naver.com',0),(16,'2025-05-14 11:06:34',4260058518,'가연','1222pgy@naver.com',0),(17,'2025-05-14 11:10:56',4260065204,'최효재','hyojae5945@nate.com',0),(19,'2025-05-14 11:14:15',4260070316,'강 성엽','piz122@naver.com',0),(20,'2025-05-14 11:16:58',4260074528,'이하영','terun23456@gmail.com',0),(21,'2025-05-14 11:17:58',4260076034,'강성운','ufo0264@naver.com',0),(22,'2025-05-14 11:19:07',4260077772,'이해루','gofn080776@gmail.com',0),(23,'2025-05-14 11:21:41',4260081633,'김태영','ktylp0728@gmail.com',0),(24,'2025-05-14 11:25:00',4260086434,'김민경','1016mk@naver.com',0),(25,'2025-05-14 11:25:59',4260087900,'우연주','wooyeonju.dohyeon@gmail.com',0),(26,'2025-05-14 11:43:49',4260113672,'고대권','konzo321@naver.com',0),(27,'2025-05-14 12:29:31',4260177541,'영진','micael101@naver.com',0),(29,'2025-05-14 13:15:31',4260242793,'제서윤','seoyun-je@daum.net',0),(30,'2025-05-14 15:21:59',4260428028,'최현만','cchh6462@daum.net',0),(31,'2025-05-14 15:53:49',4260475287,'박우담','pwd2735@naver.com',0),(32,'2025-05-14 17:41:22',4260631963,'화영','pudami@naver.com',0),(35,'2025-05-15 11:20:45',4261577021,'이신욱','lso930@naver.com',0),(36,'2025-05-15 17:10:21',4257410604,'박성근','qkrtjd50@naver.com',0),(37,'2025-05-19 15:37:33',4267668030,'JenC','jencrulz@gmail.com',0),(38,'2025-05-19 15:41:42',4267674668,'이승윤','samsee@kakao.com',0),(39,'2025-05-20 02:54:56',4268429398,'Scof','songyw0517@naver.com',0),(40,'2025-05-20 13:33:35',4268952090,'오승열','tmdduf785@naver.com',0),(41,'2025-05-20 15:08:08',4269088428,'김종권','stone361@kakao.com',0),(42,'2025-05-20 15:09:52',4269090992,'서혜원','madline1@naver.com',0),(43,'2025-05-20 15:11:12',4269092950,'유정화','wha3402@naver.com',0),(44,'2025-05-20 15:12:04',4269094181,'김민','rlaallsalls@gmail.com',0),(45,'2025-05-20 15:14:44',4269098028,'황경미','mimi7627@naver.com',0),(46,'2025-05-20 15:18:52',4269104004,'김동환','ghksdl0414@naver.com',0),(47,'2025-05-20 15:35:15',4269127804,'채니','cykim5@naver.com',0),(48,'2025-05-20 16:12:17',4269181695,'김진욱','jinuk0429@naver.com',0),(49,'2025-05-20 16:51:14',4269238019,'이현진','laplaya1411@gmail.com',0),(50,'2025-05-20 16:51:17',4269238066,'최나연','cny1213@naver.com',0),(51,'2025-05-20 16:52:00',4269239138,'김동건','tim0971@naver.com',0),(52,'2025-05-20 16:53:31',4269241277,'이민하','minhyay@nate.com',0),(53,'2025-05-20 17:10:09',4269265222,'최도혁','ehgur062300@naver.com',0),(54,'2025-05-20 17:22:00',4269282105,'이석용','dltjr98@naver.com',0),(55,'2025-05-20 17:26:42',4269288751,'서영광','joungnx123@naver.com',0),(56,'2025-05-20 17:27:15',4269289554,'박상호','ktm2048@naver.com',0),(57,'2025-05-20 17:30:10',4269293734,'혜민','hyemin3699@kakao.com',0),(59,'2025-05-20 17:31:44',4269295818,'류현','ryoo918@naver.com',0),(60,'2025-05-20 17:32:55',4269297575,'최이화','ihwa220@naver.com',0),(61,'2025-05-20 17:34:54',4269300309,'상희','maycom1234@naver.com',0),(62,'2025-05-20 17:35:19',4269300890,'이진호','zxcwlsgh12@naver.com',0),(63,'2025-05-20 17:36:11',4269302110,'김민정','99minj0731@naver.com',0),(64,'2025-05-20 17:36:26',4269302492,'최민주','minjumost@naver.com',0),(65,'2025-05-20 17:43:12',4269312022,'이민영','dlalsdud3954@hanmail.net',0),(66,'2025-05-20 17:52:10',4269324769,'이진형','ddocdoli@naver.com',0),(67,'2025-05-20 18:03:31',4260056219,'이은지','esc4874@daum.net',0),(70,'2025-05-20 18:04:16',4269341780,'조현준','wns950404@kakao.com',0),(72,'2025-05-20 18:04:52',4269341734,'선진','gene1996@naver.com',0),(73,'2025-05-20 18:05:20',4269343347,'김태경','barronhilton10@gmail.com',0),(74,'2025-05-20 18:11:23',4260192735,'이병조','qudwh0312@naver.com',0),(75,'2025-05-20 18:38:08',4269388413,'이지영','torfudvlf2@daum.net',0),(76,'2025-05-20 18:44:36',4269396810,'김지훈','kbg06090@naver.com',0),(77,'2025-05-20 19:23:09',4269446881,'이형준','gudwns9351@naver.com',0),(78,'2025-05-20 19:26:42',4269451496,'김도경♡','allcare1004@hanmail.net',0),(79,'2025-05-20 19:26:57',4269451843,'박연희','dusgml8068@naver.com',0),(80,'2025-05-20 19:36:30',4269464349,'한기리','ytth918@naver.com',0),(81,'2025-05-20 20:11:28',4269509430,'김우정','626kwj@naver.com',0),(82,'2025-05-20 20:28:32',4269531220,'이상','oh_happy_1225@daum.net',0),(83,'2025-05-20 20:37:34',4269542884,'박상미','sangmipak-_-@hanmail.net',0),(84,'2025-05-20 21:37:19',4269622322,'김형원','dalki950@naver.com',0),(85,'2025-05-20 22:44:48',4269715974,'이봉교','nbglee@naver.com',0),(86,'2025-05-21 09:02:20',4270049246,'동건','ehdrjs5198@naver.com',0),(87,'2025-05-21 09:30:51',4270080665,'유지인','jiin4083@naver.com',0),(88,'2025-05-21 09:48:29',4270101351,'이다영','daosp@naver.com',0),(93,'2025-05-21 13:29:49',4270412851,'김민주','hong00z@naver.com',0),(94,'2025-05-21 13:58:06',4270451851,'구민석','kms960914@nate.com',0),(97,'2025-05-21 14:12:53',4260052446,'송용인','thddyddls1@naver.com',0),(98,'2025-05-21 14:19:30',4270483273,'최담천','cdc826@naver.com',0),(100,'2025-05-21 14:21:28',4270485350,'편정웅','syd01022@naver.com',0),(101,'2025-05-21 14:45:50',4270521868,'전성모','jeonsm999@kakao.com',0),(102,'2025-05-21 15:25:12',4270581419,'안다빈','bini0820@kakao.com',0),(103,'2025-05-21 15:25:15',4270581476,'수정','psj3724@gmail.com',0),(104,'2025-05-21 15:25:31',4270581894,'김준혁','ricky1208@naver.com',0),(105,'2025-05-21 15:25:40',4270582134,'신재은','jenny4528@daum.net',0),(106,'2025-05-21 15:25:44',4270582250,'김봉주','babybird96@kakao.com',0),(107,'2025-05-21 15:25:45',4270582257,'이윤동','dldbsehd106@daum.net',0),(110,'2025-05-21 15:27:04',4270584287,'최이설','yoojin0322@naver.com',0),(111,'2025-05-21 15:27:08',4270584359,'연제현','jeahyunning@naver.com',0),(113,'2025-05-21 15:27:54',4270585539,'K','jkim720@naver.com',0),(114,'2025-05-21 15:27:59',4270585686,'권예경','qwer4359@naver.com',0),(115,'2025-05-21 15:28:35',4270586578,'황희준','hhjhj95@naver.com',0),(116,'2025-05-21 15:28:45',4270586819,'최원민','jd98123@daum.net',0),(117,'2025-05-21 15:29:17',4270587615,'임태원','imtaewon0123@gmail.com',0),(118,'2025-05-21 15:42:03',4270607248,'김규빈','deu08153@daum.net',0),(119,'2025-05-21 15:42:05',4270607311,'김나영','hkny0627@naver.com',0),(120,'2025-05-21 15:42:19',4270607696,'LEE HYO JIN/이효진','lizzie0315@naver.com',0),(121,'2025-05-21 15:42:20',4270607704,'김희망','gmlakd990514@naver.com',0),(122,'2025-05-21 15:42:39',4270608196,'이지민','juo2321@nate.com',0),(126,'2025-05-21 15:44:22',4270610778,'이체라','icherr09@kakao.com',0),(127,'2025-05-21 15:45:09',4270611935,'이창열','askl7798@daum.net',0),(128,'2025-05-21 15:46:16',4270613688,'백승민','als991225@nate.com',0),(129,'2025-05-21 15:46:27',4270613943,'전지환','pica104@naver.com',0),(146,'2025-05-21 15:58:25',4270609319,'강창민','ckdals0577@naver.com',0),(147,'2025-05-21 16:13:38',4270655121,'김다현','tbvjekgus@gmail.com',0),(148,'2025-05-21 17:08:10',4252697903,'대규','howeorb@nate.com',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-21 17:15:41
